export enum Screens {
  tweets = 'tweets',
  feed = 'feed',
  tweet = 'tweet',
  add = 'add',
  account = 'account',
  auth = 'auth',
  welcome = 'welcome',
  login = 'login',
  register = 'register',
}
