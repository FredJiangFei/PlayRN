export const colors = {
  pink: '#FC505A',
  light: '#dedede',
  lightGray: '#F7F2F1',
  gray: 'gray',
  red: 'red',
  white: 'white',
  black: '#313131',
  tomato: 'tomato',
  green: '#25C4B2',
  yellow: '#FECD29',
};
