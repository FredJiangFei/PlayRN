import {StyleSheet} from 'react-native';
import {colors} from '../../config';

export const styles = StyleSheet.create({
  // addMainCircle: {
  //   alignItems: 'center',
  //   justifyContent: 'center',
  //   backgroundColor: colors.white,
  //   elevation: 1,
  //   marginBottom: 40,
  //   width: 70,
  //   height: 70,
  //   borderRadius: 50,
  // },
  // addSecCircle: {
  //   marginTop: 40,
  //   alignItems: 'center',
  //   justifyContent: 'center',
  //   backgroundColor: colors.pink,
  //   marginBottom: 40,
  //   width: 55,
  //   height: 55,
  //   borderRadius: 50,
  // },
});
