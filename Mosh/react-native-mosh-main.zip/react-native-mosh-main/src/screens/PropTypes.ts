export type UploadScreenProps = {
  progress: number;
  visible: boolean;
  onDone: any;
};
