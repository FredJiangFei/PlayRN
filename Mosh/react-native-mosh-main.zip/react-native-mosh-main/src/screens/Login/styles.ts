import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  logo: {
    marginTop: 40,
    marginBottom: 10,
    alignSelf: 'center',
  },
});
