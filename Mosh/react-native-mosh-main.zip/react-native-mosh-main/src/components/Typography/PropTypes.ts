export type H4Type = {
  style?: any;
};
