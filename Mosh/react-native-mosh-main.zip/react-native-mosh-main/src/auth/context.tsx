import React from 'react';

//@ts-ignore
export const AuthContext = React.createContext();
