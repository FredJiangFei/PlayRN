export type ScreenTypes = {
  style?: any;
  type?: 'View';
};

export type TextButtonProps = {
  title: string;
  color: string;
  onPress: any;
};
