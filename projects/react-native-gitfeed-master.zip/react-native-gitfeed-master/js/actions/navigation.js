export const ROOT_SWITCH_TAB = 'ROOT_SWITCH_TAB'

export const rootSwitchTab = (rootTab) => {
  return {
    type: ROOT_SWITCH_TAB,
    rootTab
  }
}