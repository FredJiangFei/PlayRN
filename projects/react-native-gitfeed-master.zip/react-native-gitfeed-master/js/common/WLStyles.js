module.exports = {
  separator: {
    height: 1.0,
    backgroundColor: '#EEEEEE'
  },
};
