/**
 * Created by xiekaiwei on 16/8/24.
 */

import { NativeModules } from 'react-native'
export default NativeModules.DXRNUtils

