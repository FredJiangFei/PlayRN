'use strict'

import React from 'react'
import {
  AppRegistry
} from 'react-native'
import setup from './js/setup'

AppRegistry.registerComponent('gitfeed', setup)
