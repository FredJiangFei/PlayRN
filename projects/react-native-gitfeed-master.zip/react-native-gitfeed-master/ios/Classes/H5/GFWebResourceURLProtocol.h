@import Foundation;

@interface GFWebResourceURLProtocol : NSURLProtocol

@end
