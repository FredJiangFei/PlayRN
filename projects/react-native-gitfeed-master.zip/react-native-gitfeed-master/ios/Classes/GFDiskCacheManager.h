//
//  GFDiskCacheManager.h
//  RN_CNNode
//
//  Created by xiekw on 16/1/19.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"

@interface GFDiskCacheManager : NSObject<RCTBridgeModule>

@end
