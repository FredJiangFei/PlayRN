//
//  DXRefreshControl.h
//  RN_CNNode
//
//  Created by xiekw on 15/10/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"

@interface DXRefreshControl : NSObject<RCTBridgeModule>

@end
