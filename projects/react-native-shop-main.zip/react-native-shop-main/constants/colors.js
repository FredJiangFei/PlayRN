export default {
  primary: "#c2185b",
  accent: "#ffc107",
};
