var HACKER_NEWS_API_V0 = 'https://hacker-news.firebaseio.com/v0/';
exports.HN_TOP_STORIES_ENDPOINT = HACKER_NEWS_API_V0+'topstories.json';
exports.HN_NEW_STORIES_ENDPOINT = HACKER_NEWS_API_V0+'newstories.json';
exports.HN_SHOW_STORIES_ENDPOINT = HACKER_NEWS_API_V0+'showstories.json';
exports.HN_ASK_STORIES_ENDPOINT = HACKER_NEWS_API_V0+'askstories.json';
exports.HN_JOB_STORIES_ENDPOINT = HACKER_NEWS_API_V0+'jobstories.json';
exports.HN_ITEM_ENDPOINT = HACKER_NEWS_API_V0+'item/';