export default Object.freeze({
    ACCOUNT: 'Account',
    FEED: 'Feed',
    LOGIN: 'Login',
    LISTINGS: 'Listings',
    LISTINGEDIT: 'ListingEdit',
    LISTING_DETAILS: 'ListingDetails',
    MESSAGES: 'Messages',
    REGISTER: 'Register',
})