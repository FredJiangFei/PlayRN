export default {
    accent: '#FFC107',
    inputBorder: '#CCC',
    primary: '#C2185B',
    text: '#888'
};