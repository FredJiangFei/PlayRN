export default {
    primary: '#00a195',
    secondary: '#233453',
    background: '#edecef'
};