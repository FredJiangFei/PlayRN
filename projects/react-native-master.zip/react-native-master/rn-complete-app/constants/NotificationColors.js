export default {
    primary: '#D282A6'
};