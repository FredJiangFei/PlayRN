export default {
    black: '#111',
    grey: '#ccc',
    primary: '#007AFF'
}