export default {
    accent: '#9370DB',
    background: '#1e88e5',
    black: '#111',
    grey: '#999',
    inputBorder: '#CCC',
    primary: '#71bee5',
    text: '#888',
    white: '#fafafa'
};