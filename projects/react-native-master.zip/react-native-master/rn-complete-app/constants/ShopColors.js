export default {
    accent: '#FFC107',
    black: '#111',
    grey: '#999',
    inputBorder: '#CCC',
    pink1: '#ffedff',
    pink2: '#ffe3ff',
    primary: '#C2185B',
    text: '#888',
    white: '#fafafa'
};