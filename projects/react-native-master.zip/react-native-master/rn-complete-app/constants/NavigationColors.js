export default {
    accent: '#ff6f00',
    black: '#111111',
    grey: '#ccc',
    primary: '#4a148c',
    white: '#fafafa'
};