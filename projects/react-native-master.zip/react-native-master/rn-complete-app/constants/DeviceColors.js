export default {
    black: '#111',
    blackLight: '#666',
    grey: '#ccc',
    primary: '#fc9208'
}