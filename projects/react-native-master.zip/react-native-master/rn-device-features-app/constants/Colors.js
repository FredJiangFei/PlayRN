export default {
    primary: '#fc9208'
}