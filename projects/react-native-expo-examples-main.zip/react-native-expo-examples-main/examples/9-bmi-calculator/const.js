export const DEFAULT_VALUE = {
  gender: "male",
  height: 150,
  weight: 50,
  age: 20,
};
export const MIN_WEIGHT = 10;
export const MAX_WEIGHT = 150;
export const MIN_AGE = 1;
export const MAX_AGE = 150;
