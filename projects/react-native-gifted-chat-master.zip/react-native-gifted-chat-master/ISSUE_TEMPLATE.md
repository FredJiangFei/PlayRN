#### Issue Description

[FILL THIS OUT]

#### Steps to Reproduce / Code Snippets

[FILL THIS OUT]

#### Expected Results

[FILL THIS OUT]

#### Additional Information

* Nodejs version: [FILL THIS OUT]
* React version: [FILL THIS OUT]
* React Native version: [FILL THIS OUT]
* react-native-gifted-chat version: [FILL THIS OUT]
* Platform(s) (iOS, Android, or both?): [FILL THIS OUT]
* TypeScript version: [FILL THIS OUT]
