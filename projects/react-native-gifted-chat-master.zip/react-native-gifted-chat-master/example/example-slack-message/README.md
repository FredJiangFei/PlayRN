# "Slack" style UI example

Credit and inspiration comes from [Slack](https://slack.com/).

Screenshots to compare:

| Default style | "Slack" style |
|:-------------:|:-------------:|
| <img src="https://raw.githubusercontent.com/FaridSafi/react-native-gifted-chat/master/example-slack-message/example-default-style.png" alt="Example with default style" width="300"> | <img src="https://raw.githubusercontent.com/FaridSafi/react-native-gifted-chat/master/example-slack-message/example-slack-style.png" alt="Example with Slack style" width="300"> |
