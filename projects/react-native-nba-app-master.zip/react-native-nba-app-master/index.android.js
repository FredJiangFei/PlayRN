'use strict'

import {AppRegistry} from 'react-native'
import Root from './app/root'

AppRegistry.registerComponent('allyoop', () => Root)
