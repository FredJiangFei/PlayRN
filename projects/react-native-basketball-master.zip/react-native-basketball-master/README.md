# react-native-basketball

React-Native clone of the Facebook Basketball game

![](https://raw.githubusercontent.com/FaridSafi/react-native-basketball/master/capture/capture.gif)

### Versioning

For React Native 0.45.1

### Installation

- `git clone https://github.com/FaridSafi/react-native-basketball`
- `cd react-native-basketball && npm install`
- `react-native run-ios`


Feel free to ask me questions on Twitter [@FaridSafi](https://www.twitter.com/FaridSafi)!

# License

Licensed under the [MIT](LICENSE)
