import React from 'react';
import {
  AppRegistry,
} from 'react-native';

import Basketball from './Basketball';

AppRegistry.registerComponent('Basketball', () => Basketball);
