// Use next.js page for the mobile app
export { default } from './pages'