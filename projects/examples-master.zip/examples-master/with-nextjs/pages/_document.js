// @generated: @expo/next-adapter@2.1.52
export { default } from '@expo/next-adapter/document';
