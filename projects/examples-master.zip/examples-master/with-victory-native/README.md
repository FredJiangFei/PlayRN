# victory-native

## How to use

## Running the app

- Run `yarn` or `npm install`
- Run [`expo start`](https://docs.expo.dev/versions/latest/workflow/expo-cli/), to try it out!

## The idea behind the example

Expo includes `react-native-svg`, which is the only native dependency for `victory-native`. This demo shows that it's as simple as adding a supported version of `victory-native` and then using it as suggested in the docs. The code in `App.js` is copied directly out of the `victory-native` example app.
