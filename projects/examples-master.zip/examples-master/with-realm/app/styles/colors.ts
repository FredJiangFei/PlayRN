const colors = {
  darkBlue: '#2A3642',
  purple: '#6E60F9',
  gray: '#B5B5B5',
  white: '#FFFFFF',
  black: '#000000',
};

export default colors;
