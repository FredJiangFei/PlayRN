module.exports = ({ config, log }) => {
  log(config.message);
}
