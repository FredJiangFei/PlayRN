# Video Background Example

Video backgrounds are common in mobile apps. This shows you how to do it universally with Expo.

## How to use

- Install: `yarn`

- [Expo CLI](https://docs.expo.dev/versions/latest/workflow/expo-cli/): `npm install -g expo-cli` (if not already installed globally on your machine)

- Run Project Locally: `expo start`

